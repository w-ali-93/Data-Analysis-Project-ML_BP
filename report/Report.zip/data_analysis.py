# Required Python Packages
import pandas as pd
import numpy as np
import  matplotlib.pyplot as plt
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.decomposition import IncrementalPCA
from sklearn.decomposition import PCA
from sklearn.multiclass import OneVsRestClassifier
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV
from sklearn.svm import SVC
from sklearn import metrics
from sklearn import neighbors, datasets

def feature_reduction_PCA(train_x, train_y, learner):

    pca = PCA()
    pipe = Pipeline(steps=[('pca', pca), learner])

    pca.fit(train_x)
    n_components = [20, 50, 100, 150, 200, 264]
    #plt.figure(1, figsize=(4, 3))
    plt.clf()
    #plt.axes([.2, .2, .7, .7])
    plt.plot(pca.explained_variance_, linewidth=2)
    plt.axis('tight')
    plt.xlabel('n_components')
    plt.ylabel('explained_variance_')
    #plt.show()

    # Parameters of pipelines can be set using ‘__’ separated parameter names:
    estimator = GridSearchCV(pipe, dict(pca__n_components=n_components))
    print("Dimensions of feature vector: " + str(np.asarray(train_x).shape))
    print("Dimensions of label vector: " + str(np.asarray(train_y).shape))
    c, r = np.asarray(train_y).shape
    estimator.fit(np.asarray(train_x), np.asarray(train_y).reshape((c,)))

    plt.axvline(estimator.best_estimator_.named_steps['pca'].n_components,
                linestyle=':', label="n_components chosen = " + estimator.best_estimator_.named_steps['pca'].n_components)
    plt.legend(prop=dict(size=12))
    plt.show()

    n_components_final = estimator.best_estimator_.named_steps['pca'].n_components
    pca_final = PCA(n_components=n_components_final, batch_size=800)
    Xn = pca_final.fit_transform(train_x)
    return Xn

def KNN_with_LDE():
    """ Load Raw Data """
    print("loading data ...")
    # Load the Training Data
    data_path_x = "train_data.csv";
    songs_data = pd.read_csv("train_data.csv", header=None);
    # Lpad the True Labels
    data_path_y = "train_labels.csv";
    songs_labels = pd.read_csv("train_labels.csv", header=None);
    data_path_z = "test_data.csv";
    val_x = pd.read_csv("test_data.csv", header=None);

    """ Pre Process Data """
    print("preprocessing data ...")
    scaler = preprocessing.StandardScaler().fit(songs_data)
    scaler
    scaler.mean_
    scaler.scale_
    scaler.transform(songs_data)
    scaler.transform(val_x)

    """ Split training data into training data and test data for cross validation """
    print("partitioning data ...")
    train_x, test_x, train_y, test_y = train_test_split(songs_data, songs_labels, train_size=0.8, random_state=0);

    """ Perform feature reduction"""
    print("performing feature reduction ...")
    train_x_pca = PCA(21)
    train_x_pca.fit(train_x)
    train_x_reduced = train_x_pca.transform(train_x)
    test_x_reduced = train_x_pca.transform(test_x)
    val_x_reduced = train_x_pca.transform(val_x)

    """ Build the KNN model"""
    print("building model...")
    n_neighbors = 22
    weights = 'uniform'
    clf = neighbors.KNeighborsClassifier(n_neighbors, weights)
    clf.fit(train_x_reduced, np.asarray(train_y).ravel())

    """ Output accuracy results for Train and Test partitions"""
    print("Train Accuracy :: ", metrics.accuracy_score(train_y, clf.predict(train_x_reduced)));
    print("Test Accuracy ::  ", metrics.accuracy_score(test_y, clf.predict(test_x_reduced)));

    """ Export the classification results to for the Validation set to a csv file """
    df = pd.DataFrame(songs_data);
    df.to_csv('songs_data_reduced.csv', index=False, header=False);

if __name__ == "__main__":
    KNN_with_LDE();